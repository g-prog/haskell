# Changelog for words

## Unreleased changes
